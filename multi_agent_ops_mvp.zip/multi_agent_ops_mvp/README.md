# Multi-Agent Ops Automation MVP

A complete runnable MVP for a multi-agent operations automation system.

It includes:

- Intake agent
- Planner agent
- Executor agent
- Reviewer agent
- Notifier agent
- FastAPI REST API
- SQLite persistence
- Background worker queue
- Event audit log
- Artifact records
- Pluggable tools: echo, HTTP GET, file write, shell allowlist
- Custom workflow support
- Docker and docker-compose support

## 1. Local quick start

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
./run.sh
```

Open:

```text
http://127.0.0.1:8000/docs
```

## 2. Docker quick start

```bash
docker compose up --build
```

Open:

```text
http://127.0.0.1:8000/docs
```

## 3. Create a demo task

```bash
curl -X POST http://127.0.0.1:8000/tasks/demo
```

## 4. Create a file report task

```bash
curl -X POST http://127.0.0.1:8000/tasks \
  -H "Content-Type: application/json" \
  -d '{
    "goal": "Create daily operations report",
    "payload": {
      "file_path": "reports/daily.txt",
      "content": "Daily report: leads +128, conversion 7.3%, follow-up customers 23."
    },
    "priority": 7
  }'
```

## 5. Create an HTTP check task

```bash
curl -X POST http://127.0.0.1:8000/tasks \
  -H "Content-Type: application/json" \
  -d '{
    "goal": "Check website availability",
    "payload": {
      "url": "https://example.com",
      "timeout": 10
    },
    "priority": 6
  }'
```

## 6. Create a custom workflow

```bash
curl -X POST http://127.0.0.1:8000/tasks \
  -H "Content-Type: application/json" \
  -d '{
    "goal": "Ops inspection workflow",
    "payload": {
      "workflow": [
        {
          "id": "check_site",
          "name": "Check site",
          "tool": "http_get",
          "args": {"url": "https://example.com", "timeout": 10},
          "retries": 1
        },
        {
          "id": "write_report",
          "name": "Write inspection report",
          "tool": "file_write",
          "depends_on": ["check_site"],
          "args": {
            "path": "reports/site_check.txt",
            "content": "Website inspection has been executed. See task events for HTTP details.\n"
          }
        }
      ]
    }
  }'
```

## 7. Main APIs

- `GET /health` health check
- `GET /tools` list registered tools
- `POST /tasks` create task
- `GET /tasks` list tasks
- `GET /tasks/{task_id}` get task detail
- `POST /tasks/{task_id}/run` rerun queued/failed/rejected task
- `POST /tasks/{task_id}/cancel` cancel queued task
- `GET /tasks/{task_id}/events` get task audit events
- `GET /tasks/{task_id}/artifacts` get generated artifacts
- `POST /tasks/demo` create demo task
- `GET /examples/custom-workflow` get custom workflow example

## 8. Safety notes

The `shell` tool is intentionally restricted by an allowlist. By default it allows only:

```text
echo,pwd,ls,cat,python,python3
```

For production use, add:

- RBAC and user identity
- Approval flow for risky operations
- Secret manager
- Tool-level permissions
- Sandboxed execution
- Observability and alerts
- Real LLM planner integration
- Enterprise chat integrations such as Feishu, WeCom, Slack, or DingTalk
