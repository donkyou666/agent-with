from fastapi.testclient import TestClient

from app.main import app

with TestClient(app) as client:
    resp = client.get("/health")
    assert resp.status_code == 200
    assert resp.json()["ok"] is True

    resp = client.post(
        "/tasks",
        json={
            "goal": "Create a smoke-test task",
            "payload": {"message": "hello"},
            "autorun": False,
        },
    )
    assert resp.status_code == 200
    payload = resp.json()
    assert payload["goal"] == "Create a smoke-test task"
    assert payload["status"] == "queued"

print("smoke test passed")
