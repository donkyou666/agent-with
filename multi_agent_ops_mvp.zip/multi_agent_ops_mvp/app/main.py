from __future__ import annotations

import time
from contextlib import asynccontextmanager
from typing import Any, Dict, List, Optional

from fastapi import BackgroundTasks, FastAPI, HTTPException, Query

from app.config import APP_NAME, APP_VERSION, DB_PATH, WORKSPACE_DIR
from app.orchestrator import Orchestrator
from app.schemas import ArtifactRecord, EventRecord, RunResponse, TaskCreate, TaskPatch, TaskRecord
from app.store import Store
from app.tools import build_default_tools
from app.worker import Worker

store = Store(DB_PATH)
tools = build_default_tools()
orchestrator = Orchestrator(store, tools)
worker = Worker(store, orchestrator)


@asynccontextmanager
async def lifespan(app: FastAPI):
    worker.start()
    yield
    await worker.stop()


app = FastAPI(
    title=APP_NAME,
    version=APP_VERSION,
    description="Multi-agent operations automation MVP.",
    lifespan=lifespan,
)


@app.get("/")
async def root() -> Dict[str, Any]:
    return {
        "name": APP_NAME,
        "version": APP_VERSION,
        "docs": "/docs",
        "workspace": str(WORKSPACE_DIR),
        "tools": tools.list(),
    }


@app.get("/health")
async def health() -> Dict[str, Any]:
    return {"ok": True, "time": time.time()}


@app.get("/tools")
async def list_tools() -> List[Dict[str, str]]:
    return tools.list()


@app.post("/tasks", response_model=TaskRecord)
async def create_task(item: TaskCreate, background_tasks: BackgroundTasks) -> TaskRecord:
    task = store.create_task(item)
    store.append_event(task.id, "api", "info", "Task created", {"autorun": item.autorun})
    if item.autorun:
        background_tasks.add_task(orchestrator.run_task, task.id)
    return task


@app.get("/tasks", response_model=List[TaskRecord])
async def list_tasks(
    status: Optional[str] = Query(default=None),
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
) -> List[TaskRecord]:
    return store.list_tasks(status=status, limit=limit, offset=offset)


@app.get("/tasks/{task_id}", response_model=TaskRecord)
async def get_task(task_id: str) -> TaskRecord:
    task = store.get_task(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    return task


@app.patch("/tasks/{task_id}", response_model=TaskRecord)
async def patch_task(task_id: str, patch: TaskPatch) -> TaskRecord:
    task = store.get_task(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    if task.status == "running":
        raise HTTPException(status_code=409, detail="Running task cannot be modified")

    fields: Dict[str, Any] = {}
    if patch.goal is not None:
        fields["goal"] = patch.goal
    if patch.payload is not None:
        fields["payload"] = patch.payload
    if patch.priority is not None:
        fields["priority"] = patch.priority
    updated = store.update_task(task_id, **fields)
    store.append_event(task_id, "api", "info", "Task updated", fields)
    return updated


@app.post("/tasks/{task_id}/run", response_model=RunResponse)
async def run_task(task_id: str, background_tasks: BackgroundTasks) -> RunResponse:
    task = store.get_task(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    if task.status == "running":
        return RunResponse(task_id=task_id, status=task.status, message="Task is already running")
    if task.status not in {"queued", "failed", "rejected"}:
        store.update_task(task_id, status="queued", finished_at=None, error=None)
    background_tasks.add_task(orchestrator.run_task, task_id)
    return RunResponse(task_id=task_id, status="queued", message="Task has been queued")


@app.post("/tasks/{task_id}/cancel", response_model=TaskRecord)
async def cancel_task(task_id: str) -> TaskRecord:
    task = store.get_task(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    if task.status == "running":
        raise HTTPException(status_code=409, detail="This MVP does not force-cancel running tasks")
    updated = store.update_task(task_id, status="cancelled", finished_at=time.time())
    store.append_event(task_id, "api", "warning", "Task cancelled", {})
    return updated


@app.get("/tasks/{task_id}/events", response_model=List[EventRecord])
async def get_task_events(task_id: str, limit: int = Query(default=200, ge=1, le=1000)) -> List[EventRecord]:
    if store.get_task(task_id) is None:
        raise HTTPException(status_code=404, detail="Task not found")
    return store.list_events(task_id, limit=limit)


@app.get("/tasks/{task_id}/artifacts", response_model=List[ArtifactRecord])
async def get_task_artifacts(task_id: str) -> List[ArtifactRecord]:
    if store.get_task(task_id) is None:
        raise HTTPException(status_code=404, detail="Task not found")
    return store.list_artifacts(task_id)


@app.post("/tasks/demo", response_model=TaskRecord)
async def create_demo_task(background_tasks: BackgroundTasks) -> TaskRecord:
    demo = TaskCreate(
        goal="Create operations daily report",
        payload={
            "file_path": "reports/demo_daily_report.txt",
            "content": "Operations daily report\n- New leads: 128\n- Conversion rate: 7.3%\n- Follow-up customers: 23\n",
        },
        priority=7,
        created_by="demo",
        autorun=True,
    )
    task = store.create_task(demo)
    store.append_event(task.id, "api", "info", "Demo task created", {})
    background_tasks.add_task(orchestrator.run_task, task.id)
    return task


CUSTOM_WORKFLOW_EXAMPLE = {
    "goal": "Ops inspection: check website and write report",
    "payload": {
        "workflow": [
            {
                "id": "check_site",
                "name": "Check website",
                "tool": "http_get",
                "args": {"url": "https://example.com", "timeout": 10},
                "retries": 1,
            },
            {
                "id": "write_report",
                "name": "Write inspection report",
                "tool": "file_write",
                "depends_on": ["check_site"],
                "args": {
                    "path": "reports/site_check.txt",
                    "content": "Website inspection executed. See task detail for HTTP result.\n",
                },
            },
        ]
    },
}


@app.get("/examples/custom-workflow")
async def custom_workflow_example() -> Dict[str, Any]:
    return CUSTOM_WORKFLOW_EXAMPLE
