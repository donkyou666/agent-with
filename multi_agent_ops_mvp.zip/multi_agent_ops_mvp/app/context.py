from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional

from app.schemas import EventLevel, TaskRecord
from app.store import Store


@dataclass
class AgentContext:
    task: TaskRecord
    store: Store
    memory: Dict[str, Any] = field(default_factory=dict)

    def log(
        self,
        agent: str,
        message: str,
        level: EventLevel = "info",
        data: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.store.append_event(
            task_id=self.task.id,
            agent=agent,
            level=level,
            message=message,
            data=data or {},
        )
