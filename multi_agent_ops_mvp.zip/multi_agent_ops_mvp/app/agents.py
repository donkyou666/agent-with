from __future__ import annotations

import json
import re
import time
import traceback
from typing import Any, Dict, List, Optional

from app.context import AgentContext
from app.schemas import EventLevel, StepModel, ToolResult
from app.store import Store
from app.tools import ToolRegistry, post_webhook


def model_to_dict(model: Any) -> Dict[str, Any]:
    if hasattr(model, "model_dump"):
        return model.model_dump()
    return model.dict()


class BaseAgent:
    name = "base_agent"

    def __init__(self, store: Store, tools: ToolRegistry):
        self.store = store
        self.tools = tools

    def log(
        self,
        ctx: AgentContext,
        message: str,
        level: EventLevel = "info",
        data: Optional[Dict[str, Any]] = None,
    ) -> None:
        ctx.log(self.name, message, level, data)


class IntakeAgent(BaseAgent):
    name = "intake_agent"

    async def run(self, ctx: AgentContext) -> Dict[str, Any]:
        goal = ctx.task.goal.strip()
        payload = ctx.task.payload or {}
        self.log(ctx, "Received and normalized task", data={"goal": goal, "payload_keys": list(payload.keys())})

        if not goal:
            raise ValueError("task goal cannot be empty")

        normalized = {
            "goal": goal,
            "payload": payload,
            "intent": self._classify_intent(goal, payload),
            "risk": self._estimate_risk(goal, payload),
        }
        ctx.memory["intake"] = normalized
        return normalized

    @staticmethod
    def _classify_intent(goal: str, payload: Dict[str, Any]) -> str:
        text = f"{goal} {json.dumps(payload, ensure_ascii=False)}".lower()
        if "url" in payload or re.search(r"https?://", text):
            return "http_check"
        if "file_path" in payload or "path" in payload or "report" in text or "daily" in text:
            return "file_operation"
        if "command" in payload or "shell" in text:
            return "shell_operation"
        if "workflow" in payload or "steps" in payload:
            return "custom_workflow"
        return "general"

    @staticmethod
    def _estimate_risk(goal: str, payload: Dict[str, Any]) -> str:
        text = f"{goal} {json.dumps(payload, ensure_ascii=False)}".lower()
        danger_words = ["delete", "rm -rf", "drop table", "payment", "transfer", "remove database"]
        if any(word in text for word in danger_words):
            return "high"
        if "command" in payload or "shell" in text:
            return "medium"
        return "low"


class PlannerAgent(BaseAgent):
    name = "planner_agent"

    async def run(self, ctx: AgentContext) -> List[Dict[str, Any]]:
        intake = ctx.memory.get("intake") or {}
        goal = intake.get("goal", ctx.task.goal)
        payload = intake.get("payload", ctx.task.payload)
        intent = intake.get("intent", "general")
        risk = intake.get("risk", "low")

        if risk == "high" and not payload.get("approved"):
            self.log(
                ctx,
                "Planner rejected high-risk operation without approved=true",
                level="warning",
                data={"risk": risk},
            )
            raise PermissionError("high-risk task requires payload.approved=true")

        if isinstance(payload.get("workflow"), list):
            plan = self._normalize_custom_workflow(payload["workflow"])
        elif isinstance(payload.get("steps"), list):
            plan = self._normalize_custom_workflow(payload["steps"])
        else:
            plan = self._build_rule_based_plan(goal, payload, intent)

        self.log(ctx, "Generated execution plan", data={"steps": plan})
        self.store.update_task(ctx.task.id, plan=plan)
        ctx.memory["plan"] = plan
        return plan

    def _build_rule_based_plan(self, goal: str, payload: Dict[str, Any], intent: str) -> List[Dict[str, Any]]:
        if intent == "http_check":
            url = payload.get("url") or self._extract_url(goal)
            return [
                model_to_dict(
                    StepModel(
                        id="step_http_get",
                        name="HTTP availability check",
                        tool="http_get",
                        args={"url": url, "timeout": payload.get("timeout", 10)},
                        retries=1,
                        timeout_seconds=20,
                    )
                )
            ]

        if intent == "file_operation":
            path = payload.get("file_path") or payload.get("path") or "reports/output.txt"
            content = payload.get("content") or f"Task goal: {goal}\nGenerated at: {time.strftime('%Y-%m-%d %H:%M:%S')}\n"
            return [
                model_to_dict(
                    StepModel(
                        id="step_file_write",
                        name="Write operations file",
                        tool="file_write",
                        args={"path": path, "content": content, "append": payload.get("append", False)},
                        retries=0,
                        timeout_seconds=20,
                    )
                )
            ]

        if intent == "shell_operation":
            command = payload.get("command") or "echo no-command-provided"
            return [
                model_to_dict(
                    StepModel(
                        id="step_shell",
                        name="Run allowlisted command",
                        tool="shell",
                        args={"command": command, "timeout": payload.get("timeout", 30)},
                        retries=0,
                        timeout_seconds=payload.get("timeout", 30),
                    )
                )
            ]

        return [
            model_to_dict(
                StepModel(
                    id="step_echo",
                    name="Record task payload",
                    tool="echo",
                    args={"goal": goal, "payload": payload},
                    retries=0,
                    timeout_seconds=10,
                )
            )
        ]

    @staticmethod
    def _extract_url(text: str) -> Optional[str]:
        match = re.search(r"https?://[^\s]+", text)
        return match.group(0) if match else None

    @staticmethod
    def _normalize_custom_workflow(workflow: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        plan = []
        for idx, raw in enumerate(workflow, start=1):
            step = StepModel(
                id=str(raw.get("id") or f"step_{idx}"),
                name=str(raw.get("name") or f"Step {idx}"),
                agent=str(raw.get("agent") or "executor"),
                tool=str(raw.get("tool") or "echo"),
                args=dict(raw.get("args") or {}),
                depends_on=list(raw.get("depends_on") or []),
                retries=int(raw.get("retries") or 0),
                timeout_seconds=int(raw.get("timeout_seconds") or 60),
            )
            plan.append(model_to_dict(step))
        return plan


class ExecutorAgent(BaseAgent):
    name = "executor_agent"

    async def run(self, ctx: AgentContext, plan: List[Dict[str, Any]]) -> Dict[str, Any]:
        self.log(ctx, "Starting execution plan", data={"step_count": len(plan)})
        results: Dict[str, Any] = {}
        completed: set[str] = set()

        remaining = {step["id"]: StepModel(**step) for step in plan}
        while remaining:
            executable = [
                step
                for step in remaining.values()
                if all(dep in completed for dep in step.depends_on)
            ]
            if not executable:
                raise RuntimeError(f"unsatisfied dependencies: {list(remaining.keys())}")

            for step in executable:
                result = await self._run_step(ctx, step)
                results[step.id] = model_to_dict(result)
                if not result.ok:
                    raise RuntimeError(f"step failed: {step.id}: {result.error}")
                completed.add(step.id)
                remaining.pop(step.id, None)

        summary = {"ok": True, "steps": results}
        self.log(ctx, "Execution plan completed", data=summary)
        return summary

    async def _run_step(self, ctx: AgentContext, step: StepModel) -> ToolResult:
        tool = self.tools.get(step.tool)
        attempts = step.retries + 1
        last_result: Optional[ToolResult] = None

        for attempt in range(1, attempts + 1):
            self.log(
                ctx,
                f"Running step: {step.name}",
                data={"step_id": step.id, "tool": step.tool, "attempt": attempt, "args": self._safe_args(step.args)},
            )
            try:
                result = await asyncio.wait_for(tool.run(step.args, ctx), timeout=step.timeout_seconds)
            except asyncio.TimeoutError:
                result = ToolResult(ok=False, error=f"step timeout: {step.timeout_seconds}s")
            except Exception as exc:
                result = ToolResult(ok=False, error=str(exc), meta={"traceback": traceback.format_exc()[-3000:]})

            last_result = result
            self.log(
                ctx,
                "Step execution result" if result.ok else "Step execution failed",
                level="info" if result.ok else "warning",
                data={"step_id": step.id, "result": model_to_dict(result)},
            )
            if result.ok:
                return result
            if attempt < attempts:
                await asyncio.sleep(min(2 ** attempt, 10))

        assert last_result is not None
        return last_result

    @staticmethod
    def _safe_args(args: Dict[str, Any]) -> Dict[str, Any]:
        hidden_keys = {"token", "secret", "password", "api_key", "authorization"}
        safe = {}
        for key, value in args.items():
            safe[key] = "***" if key.lower() in hidden_keys else value
        return safe


class ReviewerAgent(BaseAgent):
    name = "reviewer_agent"

    async def run(self, ctx: AgentContext, execution_result: Dict[str, Any]) -> Dict[str, Any]:
        steps = execution_result.get("steps", {})
        failed = [sid for sid, result in steps.items() if not result.get("ok")]
        approved = len(failed) == 0
        review = {
            "approved": approved,
            "failed_steps": failed,
            "score": 100 if approved else 30,
            "comment": "all steps succeeded" if approved else f"failed steps: {failed}",
        }
        self.log(ctx, "Reviewed execution result", data=review, level="info" if approved else "warning")
        return review


class NotifierAgent(BaseAgent):
    name = "notifier_agent"

    async def run(self, ctx: AgentContext, final_result: Dict[str, Any]) -> None:
        message = {
            "task_id": ctx.task.id,
            "goal": ctx.task.goal,
            "status": final_result.get("status"),
            "result": final_result,
        }
        self.log(ctx, "Task completion notification", data=message)
        ok, detail = await post_webhook(message)
        if detail != "webhook not configured":
            self.log(
                ctx,
                "Webhook notification sent" if ok else "Webhook notification failed",
                level="info" if ok else "warning",
                data={"detail": detail},
            )
