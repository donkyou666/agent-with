from __future__ import annotations

import json
import sqlite3
import time
import uuid
from typing import Any, Dict, List, Optional

from app.schemas import ArtifactRecord, EventLevel, EventRecord, TaskCreate, TaskRecord


class Store:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._init_schema()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_schema(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS tasks (
                    id TEXT PRIMARY KEY,
                    goal TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    plan TEXT,
                    status TEXT NOT NULL,
                    priority INTEGER NOT NULL,
                    created_by TEXT NOT NULL,
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL,
                    started_at REAL,
                    finished_at REAL,
                    result TEXT,
                    error TEXT
                )
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_tasks_status_priority
                ON tasks(status, priority DESC, created_at ASC)
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS events (
                    id TEXT PRIMARY KEY,
                    task_id TEXT NOT NULL,
                    agent TEXT NOT NULL,
                    level TEXT NOT NULL,
                    message TEXT NOT NULL,
                    data TEXT NOT NULL,
                    created_at REAL NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_events_task_created
                ON events(task_id, created_at ASC)
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS artifacts (
                    id TEXT PRIMARY KEY,
                    task_id TEXT NOT NULL,
                    name TEXT NOT NULL,
                    type TEXT NOT NULL,
                    data TEXT NOT NULL,
                    created_at REAL NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_artifacts_task_created
                ON artifacts(task_id, created_at ASC)
                """
            )

    @staticmethod
    def _json_dumps(value: Any) -> str:
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))

    @staticmethod
    def _json_loads(value: Optional[str], default: Any = None) -> Any:
        if value is None:
            return default
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            return default

    def create_task(self, item: TaskCreate) -> TaskRecord:
        now = time.time()
        task_id = str(uuid.uuid4())
        record = TaskRecord(
            id=task_id,
            goal=item.goal,
            payload=item.payload,
            plan=None,
            status="queued",
            priority=item.priority,
            created_by=item.created_by,
            created_at=now,
            updated_at=now,
        )
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO tasks (
                    id, goal, payload, plan, status, priority, created_by,
                    created_at, updated_at, started_at, finished_at, result, error
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    record.id,
                    record.goal,
                    self._json_dumps(record.payload),
                    None,
                    record.status,
                    record.priority,
                    record.created_by,
                    record.created_at,
                    record.updated_at,
                    record.started_at,
                    record.finished_at,
                    None,
                    record.error,
                ),
            )
        return record

    def update_task(self, task_id: str, **fields: Any) -> TaskRecord:
        allowed = {
            "goal",
            "payload",
            "plan",
            "status",
            "priority",
            "started_at",
            "finished_at",
            "result",
            "error",
        }
        fields = {k: v for k, v in fields.items() if k in allowed}
        fields["updated_at"] = time.time()

        serialized: Dict[str, Any] = {}
        for key, value in fields.items():
            if key in {"payload", "plan", "result"}:
                serialized[key] = self._json_dumps(value) if value is not None else None
            else:
                serialized[key] = value

        assignments = ", ".join([f"{key} = ?" for key in serialized])
        values = list(serialized.values()) + [task_id]
        with self._connect() as conn:
            cur = conn.execute(f"UPDATE tasks SET {assignments} WHERE id = ?", values)
            if cur.rowcount == 0:
                raise KeyError(task_id)
        task = self.get_task(task_id)
        if task is None:
            raise KeyError(task_id)
        return task

    def get_task(self, task_id: str) -> Optional[TaskRecord]:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
        if row is None:
            return None
        return self._row_to_task(row)

    def list_tasks(self, status: Optional[str] = None, limit: int = 50, offset: int = 0) -> List[TaskRecord]:
        with self._connect() as conn:
            if status:
                rows = conn.execute(
                    """
                    SELECT * FROM tasks
                    WHERE status = ?
                    ORDER BY priority DESC, created_at DESC
                    LIMIT ? OFFSET ?
                    """,
                    (status, limit, offset),
                ).fetchall()
            else:
                rows = conn.execute(
                    """
                    SELECT * FROM tasks
                    ORDER BY created_at DESC
                    LIMIT ? OFFSET ?
                    """,
                    (limit, offset),
                ).fetchall()
        return [self._row_to_task(row) for row in rows]

    def next_queued_task(self) -> Optional[TaskRecord]:
        with self._connect() as conn:
            row = conn.execute(
                """
                SELECT * FROM tasks
                WHERE status = 'queued'
                ORDER BY priority DESC, created_at ASC
                LIMIT 1
                """
            ).fetchone()
        if row is None:
            return None
        return self._row_to_task(row)

    def append_event(
        self,
        task_id: str,
        agent: str,
        level: EventLevel,
        message: str,
        data: Optional[Dict[str, Any]] = None,
    ) -> EventRecord:
        event = EventRecord(
            id=str(uuid.uuid4()),
            task_id=task_id,
            agent=agent,
            level=level,
            message=message,
            data=data or {},
            created_at=time.time(),
        )
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO events (id, task_id, agent, level, message, data, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    event.id,
                    event.task_id,
                    event.agent,
                    event.level,
                    event.message,
                    self._json_dumps(event.data),
                    event.created_at,
                ),
            )
        return event

    def list_events(self, task_id: str, limit: int = 200) -> List[EventRecord]:
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT * FROM events
                WHERE task_id = ?
                ORDER BY created_at ASC
                LIMIT ?
                """,
                (task_id, limit),
            ).fetchall()
        return [self._row_to_event(row) for row in rows]

    def add_artifact(self, task_id: str, name: str, type_: str, data: Dict[str, Any]) -> ArtifactRecord:
        artifact = ArtifactRecord(
            id=str(uuid.uuid4()),
            task_id=task_id,
            name=name,
            type=type_,
            data=data,
            created_at=time.time(),
        )
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO artifacts (id, task_id, name, type, data, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    artifact.id,
                    artifact.task_id,
                    artifact.name,
                    artifact.type,
                    self._json_dumps(artifact.data),
                    artifact.created_at,
                ),
            )
        return artifact

    def list_artifacts(self, task_id: str) -> List[ArtifactRecord]:
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT * FROM artifacts
                WHERE task_id = ?
                ORDER BY created_at ASC
                """,
                (task_id,),
            ).fetchall()
        return [self._row_to_artifact(row) for row in rows]

    def _row_to_task(self, row: sqlite3.Row) -> TaskRecord:
        return TaskRecord(
            id=row["id"],
            goal=row["goal"],
            payload=self._json_loads(row["payload"], {}),
            plan=self._json_loads(row["plan"], None),
            status=row["status"],
            priority=row["priority"],
            created_by=row["created_by"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            started_at=row["started_at"],
            finished_at=row["finished_at"],
            result=self._json_loads(row["result"], None),
            error=row["error"],
        )

    def _row_to_event(self, row: sqlite3.Row) -> EventRecord:
        return EventRecord(
            id=row["id"],
            task_id=row["task_id"],
            agent=row["agent"],
            level=row["level"],
            message=row["message"],
            data=self._json_loads(row["data"], {}),
            created_at=row["created_at"],
        )

    def _row_to_artifact(self, row: sqlite3.Row) -> ArtifactRecord:
        return ArtifactRecord(
            id=row["id"],
            task_id=row["task_id"],
            name=row["name"],
            type=row["type"],
            data=self._json_loads(row["data"], {}),
            created_at=row["created_at"],
        )
