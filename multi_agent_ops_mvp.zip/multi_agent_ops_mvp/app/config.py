from __future__ import annotations

import os
from pathlib import Path

APP_NAME = "Multi-Agent Ops Automation System"
APP_VERSION = "1.0.0"

DB_PATH = os.getenv("OPS_DB_PATH", "ops_agents.db")
WORKSPACE_DIR = Path(os.getenv("OPS_WORKSPACE_DIR", "./workspace")).resolve()
WORKSPACE_DIR.mkdir(parents=True, exist_ok=True)

DEFAULT_SHELL_ALLOWLIST = "echo,pwd,ls,cat,python,python3"
SHELL_ALLOWLIST = {
    item.strip()
    for item in os.getenv("OPS_ALLOWED_CMDS", DEFAULT_SHELL_ALLOWLIST).split(",")
    if item.strip()
}

NOTIFY_WEBHOOK = os.getenv("OPS_NOTIFY_WEBHOOK", "").strip()
