from __future__ import annotations

import asyncio
from typing import Any, Optional

from app.orchestrator import Orchestrator
from app.store import Store


class Worker:
    def __init__(self, store: Store, orchestrator: Orchestrator, interval_seconds: float = 1.0):
        self.store = store
        self.orchestrator = orchestrator
        self.interval_seconds = interval_seconds
        self._stop = asyncio.Event()
        self._task: Optional[asyncio.Task[Any]] = None

    def start(self) -> None:
        if self._task is None or self._task.done():
            self._stop.clear()
            self._task = asyncio.create_task(self._loop())

    async def stop(self) -> None:
        self._stop.set()
        if self._task:
            await self._task

    async def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                task = self.store.next_queued_task()
                if task:
                    await self.orchestrator.run_task(task.id)
                else:
                    await asyncio.sleep(self.interval_seconds)
            except Exception:
                await asyncio.sleep(self.interval_seconds)
