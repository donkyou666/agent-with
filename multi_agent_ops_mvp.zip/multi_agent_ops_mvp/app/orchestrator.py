from __future__ import annotations

import asyncio
import time
import traceback
from typing import Any, Dict

from app.agents import ExecutorAgent, IntakeAgent, NotifierAgent, PlannerAgent, ReviewerAgent
from app.context import AgentContext
from app.schemas import TaskRecord
from app.store import Store
from app.tools import ToolRegistry


class Orchestrator:
    def __init__(self, store: Store, tools: ToolRegistry):
        self.store = store
        self.tools = tools
        self.intake = IntakeAgent(store, tools)
        self.planner = PlannerAgent(store, tools)
        self.executor = ExecutorAgent(store, tools)
        self.reviewer = ReviewerAgent(store, tools)
        self.notifier = NotifierAgent(store, tools)
        self._locks: Dict[str, asyncio.Lock] = {}

    def _lock_for(self, task_id: str) -> asyncio.Lock:
        if task_id not in self._locks:
            self._locks[task_id] = asyncio.Lock()
        return self._locks[task_id]

    async def run_task(self, task_id: str) -> TaskRecord:
        lock = self._lock_for(task_id)
        async with lock:
            task = self.store.get_task(task_id)
            if task is None:
                raise KeyError(task_id)
            if task.status == "running":
                return task
            if task.status not in {"queued", "failed", "rejected"}:
                return task

            task = self.store.update_task(task_id, status="running", started_at=time.time(), finished_at=None, error=None)
            ctx = AgentContext(task=task, store=self.store)
            ctx.log("orchestrator", "Task started", data={"task_id": task_id})

            try:
                await self.intake.run(ctx)
                plan = await self.planner.run(ctx)
                execution = await self.executor.run(ctx, plan)
                review = await self.reviewer.run(ctx, execution)

                if not review.get("approved"):
                    final = {"status": "rejected", "execution": execution, "review": review}
                    task = self.store.update_task(
                        task_id,
                        status="rejected",
                        finished_at=time.time(),
                        result=final,
                        error=review.get("comment"),
                    )
                else:
                    final = {"status": "succeeded", "execution": execution, "review": review}
                    task = self.store.update_task(
                        task_id,
                        status="succeeded",
                        finished_at=time.time(),
                        result=final,
                        error=None,
                    )

                ctx.task = task
                await self.notifier.run(ctx, final)
                return task

            except PermissionError as exc:
                err = str(exc)
                ctx.log("orchestrator", "Task rejected", level="warning", data={"error": err})
                task = self.store.update_task(
                    task_id,
                    status="rejected",
                    finished_at=time.time(),
                    result={"status": "rejected", "error": err},
                    error=err,
                )
                ctx.task = task
                await self.notifier.run(ctx, task.result or {})
                return task
            except Exception as exc:
                err = str(exc)
                ctx.log(
                    "orchestrator",
                    "Task failed",
                    level="error",
                    data={"error": err, "traceback": traceback.format_exc()[-4000:]},
                )
                task = self.store.update_task(
                    task_id,
                    status="failed",
                    finished_at=time.time(),
                    result={"status": "failed", "error": err},
                    error=err,
                )
                ctx.task = task
                await self.notifier.run(ctx, task.result or {})
                return task
