from __future__ import annotations

import asyncio
import json
import re
import shlex
from pathlib import Path
from typing import Any, Dict, List, Tuple
from urllib import request as urllib_request
from urllib.error import HTTPError, URLError

from app.config import NOTIFY_WEBHOOK, SHELL_ALLOWLIST, WORKSPACE_DIR
from app.context import AgentContext
from app.schemas import ToolResult


class BaseTool:
    name: str = "base"
    description: str = "base tool"

    async def run(self, args: Dict[str, Any], ctx: AgentContext) -> ToolResult:
        raise NotImplementedError


class EchoTool(BaseTool):
    name = "echo"
    description = "Return the input payload. Useful for tests and simple records."

    async def run(self, args: Dict[str, Any], ctx: AgentContext) -> ToolResult:
        return ToolResult(ok=True, output=args)


class HttpGetTool(BaseTool):
    name = "http_get"
    description = "Run an HTTP GET request for availability checks and light scraping."

    async def run(self, args: Dict[str, Any], ctx: AgentContext) -> ToolResult:
        url = str(args.get("url", "")).strip()
        timeout = int(args.get("timeout", 10))
        if not url:
            return ToolResult(ok=False, error="missing url")
        if not re.match(r"^https?://", url, re.IGNORECASE):
            return ToolResult(ok=False, error="only http/https URLs are allowed")

        def fetch() -> ToolResult:
            req = urllib_request.Request(
                url,
                headers={"User-Agent": "ops-multi-agent-system/1.0"},
                method="GET",
            )
            try:
                with urllib_request.urlopen(req, timeout=timeout) as resp:
                    body = resp.read(1024 * 256)
                    text = body.decode("utf-8", errors="replace")
                    return ToolResult(
                        ok=200 <= resp.status < 400,
                        output={
                            "status": resp.status,
                            "headers": dict(resp.headers),
                            "body_preview": text[:5000],
                        },
                        meta={"url": url},
                    )
            except HTTPError as exc:
                body = exc.read(4096).decode("utf-8", errors="replace")
                return ToolResult(
                    ok=False,
                    error=f"HTTPError {exc.code}: {exc.reason}",
                    output={"status": exc.code, "body_preview": body},
                    meta={"url": url},
                )
            except URLError as exc:
                return ToolResult(ok=False, error=f"URLError: {exc.reason}", meta={"url": url})
            except Exception as exc:
                return ToolResult(ok=False, error=str(exc), meta={"url": url})

        return await asyncio.to_thread(fetch)


class FileWriteTool(BaseTool):
    name = "file_write"
    description = "Write a file inside the workspace directory."

    async def run(self, args: Dict[str, Any], ctx: AgentContext) -> ToolResult:
        raw_path = str(args.get("path") or args.get("file_path") or "").strip()
        content = str(args.get("content", ""))
        append = bool(args.get("append", False))
        if not raw_path:
            return ToolResult(ok=False, error="missing path/file_path")

        target = (WORKSPACE_DIR / raw_path).resolve()
        if not str(target).startswith(str(WORKSPACE_DIR)):
            return ToolResult(ok=False, error="invalid path: cannot write outside workspace")

        target.parent.mkdir(parents=True, exist_ok=True)
        if append:
            await asyncio.to_thread(self._append_text, target, content)
            mode = "a"
        else:
            await asyncio.to_thread(target.write_text, content, encoding="utf-8")
            mode = "w"

        ctx.store.add_artifact(
            task_id=ctx.task.id,
            name=target.name,
            type_="file",
            data={"path": str(target), "relative_path": str(target.relative_to(WORKSPACE_DIR))},
        )
        return ToolResult(
            ok=True,
            output={"path": str(target), "mode": mode, "bytes": len(content.encode("utf-8"))},
        )

    @staticmethod
    def _append_text(path: Path, content: str) -> None:
        with path.open("a", encoding="utf-8") as f:
            f.write(content)


class ShellTool(BaseTool):
    name = "shell"
    description = "Run an allowlisted shell command inside the workspace."

    async def run(self, args: Dict[str, Any], ctx: AgentContext) -> ToolResult:
        command = str(args.get("command", "")).strip()
        timeout = int(args.get("timeout", 30))
        if not command:
            return ToolResult(ok=False, error="missing command")

        try:
            argv = shlex.split(command)
        except ValueError as exc:
            return ToolResult(ok=False, error=f"command parse error: {exc}")

        if not argv:
            return ToolResult(ok=False, error="empty command")

        executable = Path(argv[0]).name
        if executable not in SHELL_ALLOWLIST:
            return ToolResult(
                ok=False,
                error=f"command {executable!r} is not allowlisted",
                meta={"allowlist": sorted(SHELL_ALLOWLIST)},
            )

        try:
            proc = await asyncio.create_subprocess_exec(
                *argv,
                cwd=str(WORKSPACE_DIR),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout_b, stderr_b = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            stdout = stdout_b.decode("utf-8", errors="replace")
            stderr = stderr_b.decode("utf-8", errors="replace")
            return ToolResult(
                ok=proc.returncode == 0,
                output={"stdout": stdout[-10000:], "stderr": stderr[-10000:], "returncode": proc.returncode},
                error=None if proc.returncode == 0 else f"exit code {proc.returncode}",
                meta={"command": command, "cwd": str(WORKSPACE_DIR)},
            )
        except asyncio.TimeoutError:
            return ToolResult(ok=False, error=f"command timeout: {timeout}s", meta={"command": command})
        except Exception as exc:
            return ToolResult(ok=False, error=str(exc), meta={"command": command})


async def post_webhook(payload: Dict[str, Any]) -> Tuple[bool, str]:
    webhook = NOTIFY_WEBHOOK
    if not webhook:
        return True, "webhook not configured"

    def send() -> Tuple[bool, str]:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = urllib_request.Request(
            webhook,
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib_request.urlopen(req, timeout=10) as resp:
                return 200 <= resp.status < 300, f"status={resp.status}"
        except Exception as exc:
            return False, str(exc)

    return await asyncio.to_thread(send)


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: Dict[str, BaseTool] = {}

    def register(self, tool: BaseTool) -> None:
        self._tools[tool.name] = tool

    def get(self, name: str) -> BaseTool:
        if name not in self._tools:
            raise KeyError(f"unknown tool: {name}")
        return self._tools[name]

    def list(self) -> List[Dict[str, str]]:
        return [
            {"name": tool.name, "description": tool.description}
            for tool in sorted(self._tools.values(), key=lambda item: item.name)
        ]


def build_default_tools() -> ToolRegistry:
    registry = ToolRegistry()
    registry.register(EchoTool())
    registry.register(HttpGetTool())
    registry.register(FileWriteTool())
    registry.register(ShellTool())
    return registry
