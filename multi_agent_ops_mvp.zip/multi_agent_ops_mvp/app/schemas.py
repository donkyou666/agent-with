from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field

TaskStatus = Literal["queued", "running", "succeeded", "failed", "rejected", "cancelled"]
EventLevel = Literal["debug", "info", "warning", "error"]


class TaskCreate(BaseModel):
    goal: str = Field(..., description="Automation goal")
    payload: Dict[str, Any] = Field(default_factory=dict, description="Task parameters")
    priority: int = Field(default=5, ge=1, le=10, description="Priority. 10 is highest")
    created_by: str = Field(default="api", description="Creator")
    autorun: bool = Field(default=True, description="Run automatically after creation")


class TaskPatch(BaseModel):
    goal: Optional[str] = None
    payload: Optional[Dict[str, Any]] = None
    priority: Optional[int] = Field(default=None, ge=1, le=10)


class TaskRecord(BaseModel):
    id: str
    goal: str
    payload: Dict[str, Any]
    plan: Optional[List[Dict[str, Any]]] = None
    status: TaskStatus
    priority: int
    created_by: str
    created_at: float
    updated_at: float
    started_at: Optional[float] = None
    finished_at: Optional[float] = None
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None


class EventRecord(BaseModel):
    id: str
    task_id: str
    agent: str
    level: EventLevel
    message: str
    data: Dict[str, Any]
    created_at: float


class ArtifactRecord(BaseModel):
    id: str
    task_id: str
    name: str
    type: str
    data: Dict[str, Any]
    created_at: float


class ToolResult(BaseModel):
    ok: bool
    output: Any = None
    error: Optional[str] = None
    meta: Dict[str, Any] = Field(default_factory=dict)


class StepModel(BaseModel):
    id: str
    name: str
    agent: str = "executor"
    tool: str
    args: Dict[str, Any] = Field(default_factory=dict)
    depends_on: List[str] = Field(default_factory=list)
    retries: int = Field(default=0, ge=0, le=5)
    timeout_seconds: int = Field(default=60, ge=1, le=3600)


class RunResponse(BaseModel):
    task_id: str
    status: str
    message: str
